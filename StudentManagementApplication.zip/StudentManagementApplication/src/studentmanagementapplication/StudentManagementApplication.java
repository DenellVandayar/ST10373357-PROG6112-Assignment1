/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package studentmanagementapplication;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

class Student {
    private int id;
    private String name;
    private int age;
    private String email;
    private String course;

    public Student(int id, String name, int age, String email, String course) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.email = email;
        this.course = course;
    }

    public void saveStudent(ArrayList<Student> students) {
        students.add(this);
        System.out.println("Student details have been successfully saved.");
    }

    public static Student searchStudent(ArrayList<Student> students, int searchId) {
        for (Student student : students) {
            if (student.getId() == searchId) {
                return student;
            }
        }
        return null;
    }

    public static boolean deleteStudent(ArrayList<Student> students, int deleteId) {
        for (Student student : students) {
            if (student.getId() == deleteId) {
                students.remove(student);
                System.out.println("Student with student id " + deleteId + " WAS deleted!");
                return true;
            }
        }
        return false;
    }

    public static void studentReport(ArrayList<Student> students) {
        System.out.println("STUDENT REPORT");
        System.out.println("**********************************");

        int studentCount = 1;
        for (Student student : students) {
            System.out.println("STUDENT " + studentCount);
            student.displayStudentDetails(student);
            studentCount++;
        }
    }

    public int getId() {
        return id;
    }

    void displayStudentDetails(Student student) {
        System.out.println("------------------------------------------------------");
        System.out.println("STUDENT ID: " + student.getId());
        System.out.println("STUDENT NAME: " + student.getName());
        System.out.println("STUDENT AGE: " + student.getAge());
        System.out.println("STUDENT EMAIL: " + student.getEmail());
        System.out.println("STUDENT COURSE: " + student.getCourse());
        System.out.println("------------------------------------------------------");
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getEmail() {
        return email;
    }

    public String getCourse() {
        return course;
    }
}
public class StudentManagementApplication {
private static ArrayList<Student> students = new ArrayList<>();
private static Scanner scanner = new Scanner(System.in);
    
    public static void main(String[] args) {
        String entry="";
        System.out.println("STUDENT MANAGEMENT APPLICATION");
        System.out.println("Enter (1) to launch the menu or any other key to exit the application");
        entry=scanner.nextLine();
        
        if (entry.equals("1")){
            
        
        while (true) {
            displayMenu();
            int choice = getUserChoice();

            switch (choice) {
                case 1:
                    captureNewStudent();
                    break;
                case 2:
                    searchForStudent();
                    break;
                case 3:
                    deleteStudent();
                    break;
                case 4:
                    Student.studentReport(students);
                    break;
                case 5:
                    exitStudentApplication();
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        System.out.println("Enter (1) to launch the menu or any other key to exit the application");
        entry=scanner.nextLine();
            if (entry.equals("1")){
                
            }else{
              System.out.println("Exiting the application. Goodbye!");
              System.exit(0);  
            }
        }
        }else{
         System.out.println("Exiting the application. Goodbye!");
        System.exit(0);
        }
        
    }

    private static void displayMenu() {
        System.out.println("Please select one of the following menu items:");
        System.out.println("(1) Capture a new student");
        System.out.println("(2) Search for a student");
        System.out.println("(3) Delete a student");
        System.out.println("(4) Print student report");
        System.out.println("(5) Exit application");
        
    }

    private static int getUserChoice() {
        int choice = 0;
        boolean validInput = false;
        do {
            try {
                
                choice = scanner.nextInt();
                validInput = true;
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.nextLine(); // Consume the invalid input
            }
        } while (!validInput);

        scanner.nextLine(); // Consume the newline character
        return choice;
    }

    private static void captureNewStudent() {
        System.out.println("CAPTURE A NEW STUDENT");
        System.out.println("**********************************");

        System.out.print("Enter a student ID: ");
        int id = getUserChoice();

        System.out.print("Enter the student name: ");
        String name = scanner.nextLine();

        int age;
        do {
            System.out.print("Enter the student age: ");
            age = getUserChoice();
            if (age < 16) {
                System.out.println("You have entered an incorrect student age!!!");
            }
        } while (age < 16);

        System.out.print("Enter the student email: ");
        String email = scanner.nextLine();

        System.out.print("Enter the student course: ");
        String course = scanner.nextLine();

        Student student = new Student(id, name, age, email, course);
        student.saveStudent(students);
        System.out.println("");
    }

    private static void searchForStudent() {
        System.out.print("Enter the student ID to search: ");
        int searchId = getUserChoice();

        Student student = Student.searchStudent(students, searchId);
        if (student != null) {
            student.displayStudentDetails(student);
        } else {
            System.out.println("Student with student ID: " + searchId + " was not found!");
        }
    }

    private static void deleteStudent() {
        System.out.print("Enter the student ID to delete: ");
        int deleteId = getUserChoice();

        if (!Student.deleteStudent(students, deleteId)) {
            System.out.println("Student with student ID: " + deleteId + " was not found!");
        }
    }

    private static void exitStudentApplication() {
        System.out.println("Exiting the application. Goodbye!");
        System.exit(0);
    }
    
}

//Student number-ST10373357

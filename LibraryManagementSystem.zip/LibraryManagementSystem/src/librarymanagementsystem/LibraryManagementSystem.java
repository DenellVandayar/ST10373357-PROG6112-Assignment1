/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package librarymanagementsystem;

import java.util.Scanner;

class Book {
    private String title;
    private String author;
    private int year;

    public Book(String title, String author, int year) {
        this.title = title;
        this.author = author;
        this.year = year;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public int getYear() {
        return year;
    }

    @Override
    public String toString() {
        return "Title: " + title + "\nAuthor: " + author + "\nYear: " + year;
    }
}
class FictionBook extends Book {
    public FictionBook(String title, String author, int year) {
        super(title, author, year);
    }
}
class NonFictionBook extends Book {
    public NonFictionBook(String title, String author, int year) {
        super(title, author, year);
    }
}
class Library {
    private Book[] books;
    private int bookCount;

    public Library(int capacity) {
        books = new Book[capacity];
        bookCount = 0;
    }

    public void addBook(Book book) {
        if (bookCount < books.length) {
            books[bookCount++] = book;
            System.out.println("Book added to the library.");
        } else {
            System.out.println("Library is full. Cannot add more books.");
        }
    }

    public void displayAvailableBooks() {
        System.out.println("Available Books:");
        for (int i = 0; i < bookCount; i++) {
            System.out.println("Book " + (i + 1) + "\n" + books[i] + "\n");
        }
    }
}

/**
 *
 * @author user
 */
public class LibraryManagementSystem {

   
    public static void main(String[] args) {
       Scanner scanner = new Scanner(System.in);
        Library library = new Library(10); // Initialize a library with a capacity of 10 books

        while (true) {
            System.out.println("\nLibrary Management System Menu:");
            System.out.println("1. Add a Book");
            System.out.println("2. View Available Books");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    scanner.nextLine(); // Consume the newline character
                    System.out.print("Enter the title of the book: ");
                    String title = scanner.nextLine();
                    System.out.print("Enter the author of the book: ");
                    String author = scanner.nextLine();
                    System.out.print("Enter the year of publication: ");
                    int year = scanner.nextInt();

                    System.out.print("Is it a fiction book? (1 for Yes, 0 for No): ");
                    int isFiction = scanner.nextInt();
                    if (isFiction == 1) {
                        library.addBook(new FictionBook(title, author, year));
                    } else {
                        library.addBook(new NonFictionBook(title, author, year));
                    }
                    break;

                case 2:
                    library.displayAvailableBooks();
                    break;

                case 3:
                    System.out.println("Exiting the Library Management System. Goodbye!");
                    System.exit(0);
                    break;

                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }
        }  
    }
    
}
//Student number ST10373357